/**
 * Block Page — full-screen warning overlay for scam sites.
 *
 * The most critical UX moment in Cleanway: user is about to lose money
 * to a scammer. Plain language, no jargon, 5-second countdown before
 * "I understand the risk" option becomes clickable.
 *
 * Localized via chrome.i18n.getMessage (_locales/<lang>/messages.json).
 * Falls back to English if chrome.i18n is unavailable (preview mode).
 *
 * Loaded as a CLASSIC content script (manifest content_scripts, before
 * index.js) — NOT an ES module. The whole file is wrapped in an IIFE so
 * its helpers stay private and the only thing published to the shared
 * isolated-world scope is `window.__cleanwayShowBlockPage`. See the
 * bottom of the file for the export/preview mechanics.
 */

(function () {
  "use strict";

// ─── i18n helper with English fallback ────────────────────────
const BLOCK_EN = {
  block_title: "STOP",
  block_subtitle_scam: "This is a scam site",
  block_explanation: "$DOMAIN$ is pretending to be someone else so it can steal your information.",
  block_brand_impersonation: "This site pretends to be $BRAND$",
  block_scheme_heading: "How scammers use sites like this:",
  block_scheme_step1: "You will be asked for your password or bank details",
  block_scheme_step2: "The scammer steals what you type",
  block_scheme_step3: "They drain your account or steal your identity",
  block_back_button: "Go back to safety",
  block_proceed_button: "I understand the risk — open anyway",
  block_proceed_countdown: "Wait $N$ seconds…",
  block_trust_footer: "Protected by Cleanway. We never sell your data.",
  block_voice_alert: "Stop. The site $DOMAIN$ is dangerous. Do not type your password.",
  // Strategy Top-20 #4 — Annotated Evidence cards
  block_evidence_heading: "Why we blocked this site",
  // Strategy Top-20 #15 — Cultural scam explainer heading
  block_explainer_heading: "What kind of scam is this?",
  block_evidence_other_title: "A warning sign",
  block_evidence_other_body: "Our checks found something unusual about this site.",
  confidence_chip: "Confidence: $PCT$%",
};

// Evidence cards. The block page renders up to 4 of them for the verdict's
// reasons, so the user sees the concrete signs that fired, explained in
// plain words they can act on.
//
// A card is keyed by reason GROUP (content/reason-labels.js), not by the raw
// code: the scorers emit several codes for one idea (typosquatting,
// combosquatting and watchtower_typosquat all mean "imitates a brand"), and
// a person needs one card for it, not three. The title is the same reason
// line the link badges show (extension.reason) and the body explains it
// (extension.evidence), both in the browser's language. The English
// `detail` from the scorer never reaches this page: a code nobody has mapped
// yet gets a generic card in the user's language instead.
//
// scripts/test-extension-core.mjs checks that every group has an icon here
// and a reason_/evidence_ text in all ten locales.
const EVIDENCE_ICONS = {
  flagged_dangerous: "🔎",
  flagged_phishing: "🎣",
  on_blocklists: "⛔",
  on_cleanway_list: "⛔",
  threat_reports: "📡",
  spreads_malware: "🦠",
  imitates_brand: "✏️",
  lookalike_letters: "🔠",
  fake_brand_address: "🎭",
  copies_brand_icon: "🎭",
  no_https: "🔓",
  missing_protections: "🧱",
  raw_ip_address: "🔢",
  unusual_connection: "🔌",
  hidden_destination: "↪️",
  very_new_site: "🐣",
  new_certificate: "📜",
  broken_certificate: "🔓",
  high_risk_score: "📊",
  scam_words: "🪤",
  carries_personal_data: "🕵️",
  long_complex_address: "🧶",
  many_redirects: "↪️",
  risky_ending: "🌐",
  risky_registrar: "📝",
  random_name: "🎲",
  detector_suspicious: "🤖",
  not_a_real_business: "📭",
  shifty_setup: "🌀",
  padded_address: "🧩",
  shared_hosting: "🏚️",
  site_not_found: "❓",
  unreachable_abroad: "🌍",
  checks_incomplete: "⏳",
  user_content_platform: "📄",
  invalid_address: "❌",
  private_network: "🚧",
  ai_second_look: "🤖",
  well_known_site: "✅",
  popular_site: "✅",
  detector_safe: "✅",
  on_your_trusted_list: "✅",
};

// The reason group of one verdict reason, or "other" for a code the label
// table has not mapped yet (or when reason-labels.js did not load).
function _evidenceGroup(reason) {
  var labels = window.__cleanwayReasons;
  var group = labels && typeof labels.group === "function" ? labels.group(reason) : null;
  return group || "other";
}

function _evidenceCardFor(group) {
  if (group === "other") {
    return {
      icon: "⚠️",
      title: bt("block_evidence_other_title"),
      body: bt("block_evidence_other_body"),
    };
  }
  // Built at run time: the static key scan cannot see these, so the test
  // suite checks every group's reason_/evidence_ key in every locale instead.
  return {
    icon: EVIDENCE_ICONS[group] || "⚠️",
    title: bt("reason_" + group),
    body: bt("evidence_" + group),
  };
}

function bt(key, subs) {
  try {
    if (typeof chrome !== "undefined" && chrome.i18n && chrome.i18n.getMessage) {
      const msg = chrome.i18n.getMessage(key, subs || []);
      if (msg) return msg;
    }
  } catch (_) { /* preview mode */ }
  let out = BLOCK_EN[key] || key;
  if (subs && subs.length) {
    // Map each placeholder, in order of appearance, to its OWN
    // substitution (mirrors popup.js interpolate()). The previous
    // version fed subs[0] into every token, so a string combining
    // $DOMAIN$ and $BRAND$ would have rendered the same value twice.
    let i = 0;
    out = out.replace(/\$(DOMAIN|BRAND|N|PCT)\$/g, () => {
      const v = i < subs.length ? subs[i] : subs[subs.length - 1];
      i += 1;
      return String(v);
    });
  }
  return out;
}

// HTML escape (XSS safety for domain + brand substitution)
function e(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function isRTL() {
  try {
    if (typeof chrome !== "undefined" && chrome.i18n && chrome.i18n.getUILanguage) {
      return /^ar(-|$)/i.test(chrome.i18n.getUILanguage());
    }
  } catch (_) {}
  return document.documentElement.dir === "rtl";
}

// ── Grandma Mode (Strategy Top-20 #3) ────────────────────────────
//
// Calibrated for users 65+: oversized text, voice-narrated warnings,
// simplified copy. We don't change the verdict, just the way the
// verdict is delivered. The skill_level read is synchronous from
// chrome.storage; we cache it so a slow storage round-trip on a
// busy page doesn't delay the block overlay paint.
//
// voice_alerts is the Grandparent card's "Voice warnings" switch on the
// settings page. It used to be stored and never read, so the alert spoke
// whatever the switch said. Unset means the persona's default (on).
let _cachedSkillLevel = null;
let _cachedVoiceOn = true;

function _readSkillLevel(cb) {
  if (_cachedSkillLevel !== null) {
    cb(_cachedSkillLevel, _cachedVoiceOn);
    return;
  }
  try {
    chrome.storage.local.get(["skill_level", "voice_alerts"], function (data) {
      _cachedSkillLevel = (data && data.skill_level) || "regular";
      _cachedVoiceOn = !(data && data.voice_alerts === false);
      cb(_cachedSkillLevel, _cachedVoiceOn);
    });
  } catch (_) {
    cb("regular", true);
  }
}

/**
 * Speak a phrase via the Web Speech API, in the user's UI language
 * when available. Picks a voice from the platform's installed set;
 * if none match the locale we fall back to whatever the browser
 * picks by default. Voice picks vary widely across OS/browser so we
 * keep the phrase short and don't depend on any particular SSML
 * features — plain text works everywhere.
 */
function _speakAlert(text) {
  if (typeof window === "undefined" || !window.speechSynthesis) return;
  try {
    var utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.95; // slightly slower for clarity
    utterance.pitch = 1.0;
    utterance.volume = 1.0;
    // Locale hint — Web Speech picks the closest match.
    if (chrome && chrome.i18n && chrome.i18n.getUILanguage) {
      utterance.lang = chrome.i18n.getUILanguage();
    }
    // Cancel any in-flight utterance from a previous block so we don't
    // queue up multiple warnings if the user clicks through several
    // dangerous links quickly.
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
  } catch (_) {
    /* Some browsers (Brave with shields up, Firefox with TTS disabled)
       throw on the synthesis call. Non-fatal — the visual warning
       still appears. */
  }
}

// Strategy #15 — Cultural scam explainer.
//
// Fire-and-forget POST to /api/v1/explain. The block page renders
// instantly with the raw evidence cards; the explainer arrives ≤4s
// later and injects a locale-aware paragraph ("Мошенник косит под
// СберБанк" / "This looks like a PIX transfer scam" / etc). If the
// backend times out, is unreachable, or returns an error, the block
// page stays exactly as it was — no user-visible degradation.
//
// Privacy: only the signal LIST is sent, never the domain, never the
// URL, never any user identifier. See api/routers/explainer.py:1-11
// for the server-side contract.
async function _fetchScamExplainer(signals, locale) {
  if (!Array.isArray(signals) || signals.length === 0) return null;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 4000);
  try {
    // The extension's manifest whitelists https://api.cleanway.ai/* in
    // host_permissions, so content scripts may fetch it cross-origin
    // directly without a background-message hop.
    const r = await fetch("https://api.cleanway.ai/api/v1/explain", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        // Cap at 20 signals — matches backend max_length=30 with
        // slack; scoring engine rarely produces more than 4-6 anyway.
        signals: signals.slice(0, 20),
        locale: String(locale || "en").slice(0, 5),
      }),
      signal: ctrl.signal,
    });
    if (!r.ok) return null;
    const data = await r.json();
    if (!data || typeof data.explanation !== "string" || !data.explanation.trim()) {
      return null;
    }
    return data;
  } catch {
    // AbortError, network drop, JSON parse — all silent.
    return null;
  } finally {
    clearTimeout(timer);
  }
}

// Detect impersonated brand from scoring reasons
function extractBrand(reasons) {
  if (!reasons || !Array.isArray(reasons)) return null;
  for (const r of reasons) {
    if (!r || !r.detail) continue;
    // Real verdict strings (local-scorer.js:72, api scoring.py:728):
    //   "Impersonates paypal.com (high similarity)"
    //   "Uses look-alike Unicode characters to impersonate paypal.com"
    // The keyword may carry a suffix ("Typosquatting", "mimicking",
    // "Impersonates") and is often followed by a connector ("of", "to
    // be", "as") before the brand. The previous pattern (a) lacked
    // "impersonat" entirely — so the brand line NEVER rendered for a
    // real verdict, only for the preview page's synthetic strings — and
    // (b) captured the very next word, so "Typosquat of sberbank.ru"
    // rendered "pretends to be of" and "mimicking PayPal" → "…be king".
    // The brand must end on a word char so a trailing "." is never
    // swallowed, and the "(method)" tail is naturally ignored.
    const d = String(r.detail);
    const m = d.match(
      /(?:typosquat|imitat|pretend|mimic|impersonat)[a-z]*[^\w]*(?:(?:of|to\s+be|as|like)\s+)?([A-Za-z](?:[\w.-]*\w)?)/i
    );
    if (m) return m[1];
    // brand_subdomain verdicts (scoring.py:771) quote the brand instead:
    //   "Uses 'paypal' brand name in subdomain to deceive"
    const q = d.match(/'([A-Za-z](?:[\w.-]*\w)?)'\s+brand/i);
    if (q) return q[1];
  }
  return null;
}

/**
 * Show full-screen block page overlay.
 * @param {{domain: string, score?: number, reasons?: Array<{detail: string}>}} result
 */
function showBlockPage(result) {
  if (document.getElementById("ls-block-overlay")) return;

  const { domain = "", reasons = [], confidence_pct } = result || {};
  const brand = extractBrand(reasons);
  // Strategy doc #12 — render a small confidence chip near the
  // headline. We trust the server-side value (50-99) verbatim.
  // Missing field → no chip; we never invent a number.
  const confidenceChipHTML = (typeof confidence_pct === "number"
    && confidence_pct >= 50 && confidence_pct <= 99)
    ? `<div class="ls-block-confidence">${e(bt("confidence_chip", [String(confidence_pct)]))}</div>`
    : "";
  const rtl = isRTL();

  const overlay = document.createElement("div");
  overlay.id = "ls-block-overlay";
  overlay.setAttribute("role", "alertdialog");
  overlay.setAttribute("aria-modal", "true");
  overlay.setAttribute("aria-labelledby", "ls-block-title");
  if (rtl) overlay.setAttribute("dir", "rtl");

  const brandLine = brand
    ? `<p class="ls-block-brand">${e(bt("block_brand_impersonation", [brand]))}</p>`
    : "";

  // Strategy Top-20 #4 — Annotated Evidence Cards.
  //
  // Pick the top 4 distinct reason groups from the verdict's reasons
  // array (the scorer already ranks them by weight). De-duplicate by
  // group so we don't show two "imitates a brand" cards when the scorer
  // flagged typosquatting and combosquatting, or local + remote. Less is
  // more — 4 cards keep the block page readable without scrolling on a
  // phone-sized viewport. The generic "a warning sign" card for an
  // unmapped code goes last: it says the least. Its text must also stand
  // on its own: it is the only card when no code is mapped (an API answer
  // without reason codes, or reason-labels.js failed to load).
  const _seenGroup = new Set();
  const _groups = (reasons || [])
    .filter((r) => r && r.signal)
    .map((r) => _evidenceGroup(r))
    .filter((g) => !_seenGroup.has(g) && _seenGroup.add(g));
  const evidenceCards = _groups
    .filter((g) => g !== "other")
    .concat(_groups.filter((g) => g === "other"))
    .slice(0, 4)
    .map((g) => _evidenceCardFor(g));
  const evidenceHTML = evidenceCards.length
    ? `<div class="ls-block-evidence" aria-label="${e(bt("block_evidence_heading"))}">
         <h2 class="ls-block-evidence-heading">${e(bt("block_evidence_heading"))}</h2>
         <div class="ls-block-evidence-grid">
           ${evidenceCards
             .map(
               (c) => `
                 <div class="ls-block-evidence-card">
                   <span class="ls-block-evidence-icon" aria-hidden="true">${e(c.icon)}</span>
                   <div class="ls-block-evidence-text">
                     <div class="ls-block-evidence-title">${e(c.title)}</div>
                     <div class="ls-block-evidence-body">${e(c.body)}</div>
                   </div>
                 </div>`,
             )
             .join("")}
         </div>
       </div>`
    : "";

  overlay.innerHTML = `
    <style id="ls-block-styles">
      #ls-block-overlay {
        position: fixed; inset: 0; z-index: 2147483647;
        background-image:
          radial-gradient(ellipse at top, rgba(239,68,68,0.4) 0%, transparent 60%),
          radial-gradient(ellipse at bottom, rgba(15,23,42,0.8) 0%, transparent 50%),
          linear-gradient(180deg, #7f1d1d 0%, #450a0a 100%);
        color: #fef2f2;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans Arabic", sans-serif;
        /* Not align-items:center — a card taller than the screen (any phone,
           Safari on iPhone) overflowed above the top, where no scroll can
           reach: the stop sign and the title were cut off. margin:auto on
           the card centres it only when it fits. */
        display: flex; align-items: flex-start; justify-content: center;
        padding: 40px 24px; overflow-y: auto;
        animation: ls-fade-in 0.3s ease-out;
      }
      @keyframes ls-fade-in { from { opacity: 0; } to { opacity: 1; } }
      #ls-block-overlay * { box-sizing: border-box; }
      .ls-block-card {
        max-width: 560px; width: 100%; text-align: center; margin: auto 0;
        background: rgba(15, 23, 42, 0.75);
        backdrop-filter: blur(12px);
        border: 1px solid rgba(239, 68, 68, 0.4);
        border-radius: 20px;
        padding: 40px 32px;
        box-shadow: 0 30px 80px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(239, 68, 68, 0.2);
      }
      .ls-block-stop-icon {
        font-size: 72px; line-height: 1; margin-bottom: 16px;
        animation: ls-pulse 1.5s ease-in-out infinite;
      }
      @keyframes ls-pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.08); } }
      .ls-block-title {
        font-size: 56px; font-weight: 900; color: #fff;
        letter-spacing: 0.15em; margin: 0 0 8px; line-height: 1;
        text-shadow: 0 2px 20px rgba(239, 68, 68, 0.5);
      }
      .ls-block-subtitle {
        font-size: 22px; font-weight: 700; color: #fca5a5; margin: 0 0 20px;
      }
      .ls-block-domain {
        display: inline-block;
        background: rgba(239, 68, 68, 0.2);
        border: 1px solid rgba(239, 68, 68, 0.5);
        color: #fecaca;
        padding: 6px 14px; border-radius: 8px;
        font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
        font-size: 15px; font-weight: 600; margin-bottom: 20px;
        word-break: break-all;
      }
      .ls-block-explanation {
        font-size: 16px; color: #fee2e2; line-height: 1.5; margin: 0 0 8px;
      }
      .ls-block-brand {
        font-size: 14px; color: #fca5a5; font-style: italic; margin: 0 0 24px;
      }
      .ls-block-confidence {
        display: inline-block;
        padding: 4px 10px;
        margin: 0 0 18px;
        font-size: 11px;
        font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
        letter-spacing: 0.02em;
        color: #cbd5e1;
        background: rgba(15, 23, 42, 0.5);
        border: 1px solid rgba(148, 163, 184, 0.25);
        border-radius: 999px;
      }
      .ls-block-evidence {
        background: rgba(0, 0, 0, 0.32);
        border-radius: 14px; padding: 20px;
        margin-bottom: 20px; text-align: start;
        border: 1px solid rgba(239, 68, 68, 0.18);
      }
      /* Strategy #15 — Cultural scam explainer.
         Sits above the evidence grid. Softer border + lighter tint so
         the evidence cards still get the strongest visual weight. */
      .ls-block-explainer {
        background: rgba(15, 23, 42, 0.55);
        border-radius: 14px; padding: 18px 20px;
        margin-bottom: 16px; text-align: start;
        border: 1px solid rgba(148, 163, 184, 0.22);
        animation: ls-fade-in 0.35s ease-out;
      }
      .ls-block-explainer-heading {
        font-size: 12px; font-weight: 700; color: #cbd5f5; margin: 0 0 8px;
        text-transform: uppercase; letter-spacing: 0.06em;
      }
      .ls-block-explainer-body {
        font-size: 15px; color: #e2e8f0; margin: 0; line-height: 1.5;
      }
      .ls-block-evidence-heading {
        font-size: 13px; font-weight: 700; color: #fecaca; margin: 0 0 14px;
        text-transform: uppercase; letter-spacing: 0.05em;
      }
      .ls-block-evidence-grid {
        display: grid; grid-template-columns: 1fr; gap: 10px;
      }
      @media (min-width: 480px) {
        .ls-block-evidence-grid { grid-template-columns: 1fr 1fr; }
      }
      .ls-block-evidence-card {
        display: flex; gap: 12px; align-items: flex-start;
        background: rgba(127, 29, 29, 0.25);
        border: 1px solid rgba(239, 68, 68, 0.25);
        border-radius: 10px; padding: 10px 12px;
      }
      .ls-block-evidence-icon {
        flex-shrink: 0; font-size: 22px; line-height: 1.1;
      }
      .ls-block-evidence-title {
        font-size: 14px; font-weight: 700; color: #fff;
        margin-bottom: 3px; line-height: 1.25;
      }
      .ls-block-evidence-body {
        font-size: 12.5px; color: #fee2e2; line-height: 1.4;
      }
      .ls-block-scheme {
        background: rgba(0, 0, 0, 0.3);
        border-radius: 14px; padding: 20px;
        margin-bottom: 28px; text-align: start;
      }
      .ls-block-scheme-heading {
        font-size: 13px; font-weight: 700; color: #fecaca; margin: 0 0 12px;
        text-transform: uppercase; letter-spacing: 0.05em;
      }
      .ls-block-scheme-step {
        display: flex; gap: 12px; align-items: flex-start;
        margin: 10px 0; color: #fee2e2; font-size: 14px; line-height: 1.5;
      }
      .ls-block-scheme-step .ls-step-num {
        flex-shrink: 0; width: 26px; height: 26px; border-radius: 50%;
        background: rgba(239, 68, 68, 0.3); color: #fff;
        display: inline-flex; align-items: center; justify-content: center;
        font-size: 13px; font-weight: 800;
        border: 1px solid rgba(239, 68, 68, 0.6);
      }
      .ls-block-actions {
        display: flex; flex-direction: column; gap: 12px; margin-top: 8px;
      }
      .ls-block-btn {
        display: block; width: 100%; padding: 16px 24px;
        border-radius: 12px; font-family: inherit; font-weight: 700; font-size: 17px;
        border: none; cursor: pointer; text-align: center;
        transition: transform 0.1s, background 0.15s, opacity 0.15s;
      }
      .ls-block-btn-back {
        background: #22c55e; color: #052e16;
        box-shadow: 0 6px 18px rgba(34, 197, 94, 0.3);
      }
      .ls-block-btn-back:hover { background: #16a34a; transform: translateY(-2px); }
      .ls-block-btn-proceed {
        background: transparent; color: #cbd5e1;
        border: 1px solid rgba(148, 163, 184, 0.3);
        font-size: 13px; font-weight: 500; padding: 10px 20px;
      }
      .ls-block-btn-proceed:not(:disabled):hover {
        background: rgba(148, 163, 184, 0.1); color: #e2e8f0;
      }
      .ls-block-btn-proceed:disabled { opacity: 0.5; cursor: wait; }
      .ls-block-footer {
        margin-top: 28px; font-size: 11px;
        color: rgba(254, 226, 226, 0.5);
        display: flex; align-items: center; justify-content: center; gap: 6px;
      }
      @media (max-width: 480px) {
        .ls-block-card { padding: 28px 20px; }
        .ls-block-title { font-size: 44px; }
        .ls-block-subtitle { font-size: 18px; }
        .ls-block-stop-icon { font-size: 60px; }
      }
    </style>

    <div class="ls-block-card" role="document">
      <div class="ls-block-stop-icon" aria-hidden="true">&#x26D4;</div>
      <h1 id="ls-block-title" class="ls-block-title">${e(bt("block_title"))}</h1>
      <p class="ls-block-subtitle">${e(bt("block_subtitle_scam"))}</p>
      <div class="ls-block-domain" dir="ltr">${e(domain)}</div>
      <p class="ls-block-explanation">${e(bt("block_explanation", [domain]))}</p>
      ${brandLine}
      ${confidenceChipHTML}

      ${evidenceHTML}

      <div class="ls-block-scheme">
        <h2 class="ls-block-scheme-heading">${e(bt("block_scheme_heading"))}</h2>
        <div class="ls-block-scheme-step">
          <span class="ls-step-num">1</span>
          <span>${e(bt("block_scheme_step1"))}</span>
        </div>
        <div class="ls-block-scheme-step">
          <span class="ls-step-num">2</span>
          <span>${e(bt("block_scheme_step2"))}</span>
        </div>
        <div class="ls-block-scheme-step">
          <span class="ls-step-num">3</span>
          <span>${e(bt("block_scheme_step3"))}</span>
        </div>
      </div>

      <div class="ls-block-actions">
        <button id="ls-block-back" class="ls-block-btn ls-block-btn-back" type="button">
          &#x2190; ${e(bt("block_back_button"))}
        </button>
        <button id="ls-block-proceed" class="ls-block-btn ls-block-btn-proceed" type="button" disabled>
          ${e(bt("block_proceed_countdown", ["5"]))}
        </button>
      </div>

      <p class="ls-block-footer">
        <span aria-hidden="true">&#x1F512;</span>
        <span>${e(bt("block_trust_footer"))}</span>
      </p>
    </div>
  `;

  document.body.appendChild(overlay);
  const prevOverflow = document.body.style.overflow;
  document.body.style.overflow = "hidden";

  // Strategy #15 — kick off the cultural explainer AFTER the overlay is
  // painted so the block page never blocks on network. When the
  // explainer resolves, inject a small "why this looks like a scam"
  // paragraph above the evidence grid. Null response = silent skip.
  (function _wireExplainer() {
    var signalsForExplainer = (reasons || [])
      .map(function (r) { return r && r.signal ? String(r.signal) : ""; })
      .filter(Boolean);
    var localeForExplainer = "en";
    try {
      if (typeof chrome !== "undefined" && chrome.i18n && chrome.i18n.getUILanguage) {
        localeForExplainer = String(chrome.i18n.getUILanguage()).slice(0, 2);
      } else if (typeof navigator !== "undefined" && navigator.language) {
        localeForExplainer = String(navigator.language).slice(0, 2);
      }
    } catch (_) { /* leave as "en" */ }
    _fetchScamExplainer(signalsForExplainer, localeForExplainer).then(function (data) {
      if (!data || !data.explanation) return;
      // Overlay may have been dismissed by the user before we resolved
      // — no-op if the overlay is gone.
      var live = document.getElementById("ls-block-overlay");
      if (!live) return;
      var host = live.querySelector(".ls-block-evidence");
      var card = live.querySelector(".ls-block-card");
      if (!card) return;
      var block = document.createElement("div");
      block.className = "ls-block-explainer";
      block.setAttribute("data-source", String(data.source || ""));
      block.setAttribute("data-category", String(data.category || ""));
      // Content: an h3 for screen readers + the explanation text.
      // We keep it plain text — the backend already localizes per
      // Cleanway's SAFE_KEYS whitelist so nothing user-controlled
      // ever reaches innerHTML here.
      var heading = document.createElement("h3");
      heading.className = "ls-block-explainer-heading";
      heading.textContent = bt("block_explainer_heading");
      var body = document.createElement("p");
      body.className = "ls-block-explainer-body";
      body.textContent = String(data.explanation);
      block.appendChild(heading);
      block.appendChild(body);
      if (host && host.parentNode === card) {
        card.insertBefore(block, host);
      } else {
        card.appendChild(block);
      }
    }).catch(function () { /* swallow — fire-and-forget */ });
  })();

  // Strategy #3 — Grandma Mode behaviour.
  //
  // Apply once the overlay is in the DOM so the CSS variable cascade
  // takes effect on the painted node. We:
  //   - set an attribute on the overlay so the stylesheet can up-size
  //     fonts via attribute selectors,
  //   - inject inline overrides (CSS variables) to guarantee the
  //     overrides land regardless of the platform's default font
  //     size, and
  //   - kick off a voice alert in the user's UI locale.
  _readSkillLevel(function (lvl, voiceOn) {
    // Strategy doc Top-20 #9 — skill personas. Granny up-sizes
    // everything for low vision and reads aloud. Kids strips
    // away every escape hatch and shows only a giant STOP.
    // Pro switches the page into evidence-table mode for a
    // power user who wants to see the raw numbers.
    if (lvl === "kids") {
      overlay.setAttribute("data-skill", "kids");
      // Hide the "I understand the risk — open anyway" escape hatch.
      // A child should NOT be able to override a verdict from the block
      // page. NB: the button's real id is #ls-block-proceed — an earlier
      // revision queried a non-existent #ls-block-continue, so this
      // never matched and Kids mode silently left the bypass clickable
      // after the 5s countdown. display:none survives the countdown's
      // later disabled=false / textContent updates.
      var continueBtn = overlay.querySelector("#ls-block-proceed");
      if (continueBtn) continueBtn.style.display = "none";
      var backBtnEl = overlay.querySelector(".ls-block-btn-back");
      if (backBtnEl) {
        // Keep "Go back" — it's the safe action — but make it the
        // only obvious choice.
        backBtnEl.style.fontSize = "24px";
        backBtnEl.style.padding = "22px 32px";
      }
      // Bigger icon, no scheme/scam-explainer text — children
      // can't be expected to parse phishing semantics, just the
      // visual STOP cue.
      var stopIcon = overlay.querySelector(".ls-block-stop-icon");
      if (stopIcon) stopIcon.style.fontSize = "140px";
      var titleEl = overlay.querySelector(".ls-block-title");
      if (titleEl) titleEl.style.fontSize = "64px";
      var scheme = overlay.querySelector(".ls-block-scheme");
      if (scheme) scheme.style.display = "none";
      var evidence = overlay.querySelector(".ls-block-evidence");
      if (evidence) evidence.style.display = "none";
      // The numeric confidence chip is a technical signal too — strip
      // it along with the scheme + evidence so a child sees only STOP.
      var kidsChip = overlay.querySelector(".ls-block-confidence");
      if (kidsChip) kidsChip.style.display = "none";
    } else if (lvl === "pro") {
      overlay.setAttribute("data-skill", "pro");
      // Pro mode: shrink the alarmist hero, expand the evidence
      // section. Show the confidence chip more prominently so the
      // operator can decide whether to overrule.
      var heroIcon = overlay.querySelector(".ls-block-stop-icon");
      if (heroIcon) {
        heroIcon.style.fontSize = "48px";
        heroIcon.style.opacity = "0.7";
      }
      var heroTitle = overlay.querySelector(".ls-block-title");
      if (heroTitle) {
        heroTitle.style.fontSize = "28px";
        heroTitle.style.letterSpacing = "0.06em";
      }
      var heroSub = overlay.querySelector(".ls-block-subtitle");
      if (heroSub) heroSub.style.display = "none";
      var explanation = overlay.querySelector(".ls-block-explanation");
      if (explanation) explanation.style.display = "none";
      // Promote the confidence chip — it's the field a pro reads first.
      var chip = overlay.querySelector(".ls-block-confidence");
      if (chip) {
        chip.style.fontSize = "13px";
        chip.style.background = "rgba(15, 23, 42, 0.7)";
        chip.style.borderColor = "rgba(148, 163, 184, 0.5)";
        chip.style.padding = "6px 14px";
      }
      // Open the evidence section by default, larger headings.
      var evHeading = overlay.querySelector(".ls-block-evidence-heading");
      if (evHeading) evHeading.style.fontSize = "16px";
    } else if (lvl === "granny") {
      overlay.setAttribute("data-skill", "granny");
      // Inline overrides — these out-scale the base values defined in
      // the embedded <style> above. We intentionally bump fonts by
      // ~45% (16→24, 22→32, 56→80) and increase line-height for
      // readability. Buttons go from 17 → 22 to make taps easier with
      // tremor / poor vision.
      var card = overlay.querySelector(".ls-block-card");
      if (card) card.style.padding = "56px 36px";
      var title = overlay.querySelector(".ls-block-title");
      if (title) {
        title.style.fontSize = "80px";
        title.style.letterSpacing = "0.18em";
      }
      var subtitle = overlay.querySelector(".ls-block-subtitle");
      if (subtitle) subtitle.style.fontSize = "32px";
      var explanation = overlay.querySelector(".ls-block-explanation");
      if (explanation) {
        explanation.style.fontSize = "24px";
        explanation.style.lineHeight = "1.6";
      }
      var domEl = overlay.querySelector(".ls-block-domain");
      if (domEl) domEl.style.fontSize = "20px";
      var stepsBtns = overlay.querySelectorAll(".ls-block-scheme-step, .ls-block-btn-back");
      stepsBtns.forEach(function (el) {
        if (el.classList.contains("ls-block-btn-back")) {
          el.style.fontSize = "22px";
          el.style.padding = "22px 28px";
        } else {
          el.style.fontSize = "20px";
        }
      });
      // Evidence card text up-sizing — keeps cards readable for users
      // with vision impairments without overflowing the column.
      var evTitles = overlay.querySelectorAll(".ls-block-evidence-title");
      evTitles.forEach(function (el) { el.style.fontSize = "18px"; });
      var evBodies = overlay.querySelectorAll(".ls-block-evidence-body");
      evBodies.forEach(function (el) { el.style.fontSize = "16px"; el.style.lineHeight = "1.5"; });
      var evIcons = overlay.querySelectorAll(".ls-block-evidence-icon");
      evIcons.forEach(function (el) { el.style.fontSize = "28px"; });
      // Confidence chip was the one text node left at its 11px base
      // while everything around it grew — unreadable for the exact
      // low-vision user this persona exists for.
      var grannyChip = overlay.querySelector(".ls-block-confidence");
      if (grannyChip) {
        grannyChip.style.fontSize = "16px";
        grannyChip.style.padding = "6px 14px";
      }

      // Voice alert, in the browser's language (bt falls back to the
      // English BLOCK_EN text only outside the extension), unless the
      // settings page's "Voice warnings" switch is off.
      if (voiceOn) {
        try {
          _speakAlert(bt("block_voice_alert", [domain]));
        } catch (_) {
          /* speech failure non-fatal — visual block stays. */
        }
      }
    }
  });

  // "Go back" — navigate to previous page (safest) or close tab
  const backBtn = overlay.querySelector("#ls-block-back");
  if (backBtn) {
    backBtn.addEventListener("click", () => {
      if (window.history.length > 1) {
        window.history.back();
      } else {
        try {
          if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
            chrome.runtime.sendMessage({ type: "CLOSE_TAB" });
          } else {
            window.close();
          }
        } catch (_) { window.close(); }
      }
    });
    // Keyboard focus on the safe choice, but the view stays at the top: on a
    // phone the button is below the fold, and focus() scrolled the stop sign
    // and the title out of sight (seen in Safari on the iPhone simulator).
    backBtn.focus({ preventScroll: true });
  }

  // "I understand the risk" — enabled after 5-second countdown
  const proceedBtn = overlay.querySelector("#ls-block-proceed");
  if (proceedBtn) {
    let countdown = 5;
    proceedBtn.textContent = bt("block_proceed_countdown", [String(countdown)]);
    const interval = setInterval(() => {
      countdown--;
      if (countdown > 0) {
        proceedBtn.textContent = bt("block_proceed_countdown", [String(countdown)]);
      } else {
        clearInterval(interval);
        proceedBtn.disabled = false;
        proceedBtn.textContent = bt("block_proceed_button");
        proceedBtn.addEventListener("click", () => {
          overlay.remove();
          document.body.style.overflow = prevOverflow;
        }, { once: true });
      }
    }, 1000);
  }

  // Keyboard handling.
  //   Escape        → same as "Go back".
  //   Tab/Shift+Tab → stay INSIDE the overlay. aria-modal="true" is only
  //     a hint to assistive tech; browsers do not enforce it by trapping
  //     focus. Without this trap a keyboard user pressing Shift+Tab from
  //     "Go back" lands in the last focusable control of the blocked page
  //     underneath — which is still fully interactive (e.g. the phishing
  //     login form), just hidden under our z-index. That defeats the
  //     whole point of the block page for keyboard / screen-reader users.
  overlay.addEventListener("keydown", (ev) => {
    if (ev.key === "Escape") {
      ev.preventDefault();
      if (backBtn) backBtn.click();
      return;
    }
    if (ev.key !== "Tab") return;
    // Only controls a user can actually reach right now: this skips the
    // disabled countdown button and anything a persona has hidden (Kids
    // removes the bypass entirely via display:none → offsetParent null).
    var focusable = Array.prototype.filter.call(
      overlay.querySelectorAll("button:not([disabled])"),
      function (el) { return el.offsetParent !== null; }
    );
    if (!focusable.length) { ev.preventDefault(); return; }
    var first = focusable[0];
    var last = focusable[focusable.length - 1];
    var active = document.activeElement;
    var outside = !overlay.contains(active);
    if (ev.shiftKey) {
      if (active === first || outside) { ev.preventDefault(); last.focus(); }
    } else {
      if (active === last || outside) { ev.preventDefault(); first.focus(); }
    }
  });
}

// ── Publish the entry point ─────────────────────────────────────────
//
// MV3 content scripts listed in manifest `content_scripts[].js` execute
// as CLASSIC scripts sharing one isolated-world global — they cannot use
// ESM `import`, and this file is not a web_accessible_resource, so a
// dynamic import() of it would 404 from a content script anyway. The
// working mechanism is exactly what local-scorer.js uses: assign to a
// global that the later-loaded index.js reads. The IIFE wrapper (top of
// file) keeps every internal helper (e, bt, EVIDENCE_ICONS, extractBrand,
// …) private so they can't collide with the other content scripts'
// top-level declarations — only this one namespaced entry point leaks.
if (typeof window !== "undefined") {
  window.__cleanwayShowBlockPage = showBlockPage;

  // Preview hook — call from standalone preview HTML without chrome.* APIs.
  window.__LS_BLOCK_PREVIEW__ = function (opts) {
    showBlockPage({
      domain: (opts && opts.domain) || "sberbank-secure-login.ru",
      score: 95,
      reasons: (opts && opts.reasons) || [
        { detail: "Typosquat of sberbank.ru" },
        { detail: "Domain registered 2 days ago" },
      ],
    });
  };
}

})();

/**
 * Cleanway API Client
 *
 * Handles communication with the Cleanway backend.
 * Privacy: only domain names are sent — never full URLs or page content.
 */

// API base resolution: chrome.storage.local.api_url (dev override) → production Railway URL
// To use local dev: Options page → set API URL to http://localhost:8000 → Save
import { DEVICE_ID_KEY, linkDevice } from "./device-link.js";
import { KEYS as AUTH_KEYS } from "./auth-session.js";

let API_BASE = "https://api.cleanway.ai";
try {
  chrome.storage.local.get("api_url").then(function(data) {
    if (data && typeof data.api_url === "string" && data.api_url.startsWith("http")) {
      API_BASE = data.api_url.replace(/\/$/, "");
    }
  }).catch(function() {});
  chrome.storage.onChanged.addListener(function(changes, area) {
    if (area === "local" && changes && changes.api_url && typeof changes.api_url.newValue === "string") {
      API_BASE = changes.api_url.newValue.replace(/\/$/, "");
    }
  });
} catch (e) { /* storage not available (tests, edge cases) */ }

/**
 * Soft-delete (410) detection.
 *
 * When the backend returns 410 Gone to any authed call, the user's
 * account is in the 30-day grace window. We flag this in
 * chrome.storage.local so the popup can render a lock screen with a
 * restore CTA on next open. Every authed helper below calls
 * `_handleAuthedResponse(resp)` which sets this flag on 410.
 *
 * The popup clears the flag when /restore succeeds.
 */
const ACCOUNT_LOCKED_KEY = "account_locked";

async function _markAccountLocked(restoreUrl) {
  try {
    await chrome.storage.local.set({
      [ACCOUNT_LOCKED_KEY]: {
        locked_at: new Date().toISOString(),
        restore_url: restoreUrl || "/api/v1/user/account/restore",
      },
    });
  } catch (e) { /* storage unavailable — non-fatal */ }
}

export async function clearAccountLocked() {
  try {
    await chrome.storage.local.remove(ACCOUNT_LOCKED_KEY);
  } catch (e) { /* storage unavailable — non-fatal */ }
}

export async function isAccountLocked() {
  try {
    const d = await chrome.storage.local.get(ACCOUNT_LOCKED_KEY);
    return d && d[ACCOUNT_LOCKED_KEY] ? d[ACCOUNT_LOCKED_KEY] : null;
  } catch (e) { return null; }
}

/**
 * Headers for a signed-in call: the token plus this install's device id, so
 * the server can refuse a browser that was unlinked from the account
 * (403 device_revoked, handled below).
 */
async function _authHeaders(token, extra = {}) {
  const headers = { ...extra, Authorization: `Bearer ${token}` };
  const id = await getDeviceHash();
  if (id) headers["X-Device-Id"] = id;
  return headers;
}

/**
 * This browser was unlinked from the account (on another device or on
 * cleanway.ai/account): forget the sign-in and the install id, and leave the
 * reason the popup and settings show. The next sign-in is a new device.
 */
export async function signOutUnlinkedBrowser() {
  try {
    await chrome.storage.local.remove([
      AUTH_KEYS.access, AUTH_KEYS.refresh, AUTH_KEYS.expiresAt, AUTH_KEYS.email,
      AUTH_KEYS.userId, AUTH_KEYS.anonKey, DEVICE_ID_KEY,
    ]);
    await chrome.storage.local.set({ [AUTH_KEYS.signedOutReason]: "device_revoked" });
  } catch (e) { /* storage unavailable — the next heartbeat signs out */ }
}

/** Forget this install's device id; getDeviceHash() makes a new one. */
export async function resetDeviceHash() {
  try {
    await chrome.storage.local.remove(DEVICE_ID_KEY);
  } catch (e) { /* storage unavailable */ }
}

/**
 * Inspect an authed-fetch response. On 410, mark the local lock flag
 * (extracting restore_url from the JSON detail if present) and return
 * true so callers can short-circuit. A 403 `device_revoked` signs this
 * browser out (returns false: the caller treats it as the error it is).
 * Otherwise returns false.
 */
async function _handleAuthedResponse(resp) {
  if (resp.status === 403) {
    try {
      const body = await resp.clone().json();
      if (body && body.detail && body.detail.code === "device_revoked") await signOutUnlinkedBrowser();
    } catch (e) { /* not JSON */ }
    return false;
  }
  if (resp.status !== 410) return false;
  // Parse without throwing — if body isn't JSON or restore_url isn't in
  // it, we still set the lock with the default route.
  let restoreUrl = null;
  try {
    const body = await resp.clone().json();
    if (body && body.detail && typeof body.detail === "object" && typeof body.detail.restore_url === "string") {
      restoreUrl = body.detail.restore_url;
    } else if (body && typeof body.restore_url === "string") {
      restoreUrl = body.restore_url;
    }
  } catch (e) { /* not JSON or already consumed */ }
  await _markAccountLocked(restoreUrl);
  return true;
}

/**
 * Call POST /api/v1/user/account/restore. Used by the popup's lock
 * screen "Restore" button. On success clears the lock flag.
 *
 * @param {string} token JWT
 * @returns {Promise<{ok: boolean, status?: number, error?: string}>}
 */
export async function restoreAccount(token) {
  if (!token) return { ok: false, error: "no_token" };
  try {
    const resp = await fetch(`${API_BASE}/api/v1/user/account/restore`, {
      method: "POST",
      headers: await _authHeaders(token),
    });
    if (resp.ok) {
      await clearAccountLocked();
      return { ok: true };
    }
    return { ok: false, status: resp.status };
  } catch (e) {
    return { ok: false, error: String(e && e.message ? e.message : e) };
  }
}

/**
 * Check domains against Cleanway API
 * @param {string[]} domains - List of domain names to check
 * @param {string} [token] - Optional JWT auth token
 * @returns {Promise<{results: Array, checked_at: string, api_calls_remaining: number}>}
 */
export async function checkDomains(domains, token = null) {
  const headers = { "Content-Type": "application/json" };
  if (token) {
    Object.assign(headers, await _authHeaders(token));
  }

  try {
    const resp = await fetch(`${API_BASE}/api/v1/check`, {
      method: "POST",
      headers,
      body: JSON.stringify({ domains }),
    });

    if (resp.status === 429) {
      const data = await resp.json();
      return { error: "rate_limit", detail: data.detail };
    }

    if (await _handleAuthedResponse(resp)) {
      return { error: "account_locked", status: 410 };
    }

    if (!resp.ok) {
      return { error: "api_error", status: resp.status };
    }

    return await resp.json();
  } catch (e) {
    return { error: "network_error", message: e.message };
  }
}

/**
 * Resolve a stable device hash (UUID v4) for this browser install.
 *
 * Persisted in chrome.storage.local so it survives popup/options
 * reloads and extension restarts. A user reinstalling the extension
 * gets a new hash — that's intentional: it represents "this install"
 * not "this physical machine", which matches how the backend
 * `devices` table is keyed (user_id + device_hash UNIQUE).
 *
 * @returns {Promise<string>}
 */
export async function getDeviceHash() {
  try {
    const stored = await chrome.storage.local.get("device_hash");
    if (stored && typeof stored.device_hash === "string" && stored.device_hash.length > 0) {
      return stored.device_hash;
    }
    const fresh = generateUuid();
    await chrome.storage.local.set({ device_hash: fresh });
    return fresh;
  } catch {
    // Storage unavailable (preview / very edge cases) — return a
    // session-scoped UUID. Won't persist but the helper still returns
    // a string so callers don't have to null-check.
    return generateUuid();
  }
}

function generateUuid() {
  // crypto.randomUUID is available in MV3 service workers + popups
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }
  // Fallback for older runtimes
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

/**
 * Fetch the resolved effective skill + accessibility for THIS device.
 *
 * Returns { device_hash, skill_level, voice_alerts_enabled, font_scale,
 *           skill_source, voice_source, font_source }
 * where each *_source is "device_override" or "user_default" — used by
 * the options UI to show "Set on this device" badges per field.
 *
 * @param {string|null} token JWT
 * @param {string} deviceHash from getDeviceHash()
 * @returns {Promise<object|null>}
 */
export async function fetchEffectiveSkill(token, deviceHash) {
  if (!token || !deviceHash) return null;
  try {
    const url = `${API_BASE}/api/v1/user/device/${encodeURIComponent(deviceHash)}/effective`;
    const resp = await fetch(url, {
      method: "GET",
      headers: await _authHeaders(token),
    });
    if (await _handleAuthedResponse(resp)) return null;
    if (!resp.ok) return null;
    return await resp.json();
  } catch {
    return null;
  }
}

/**
 * PATCH device-scoped overrides — Family Hub use case (admin enables
 * Granny Mode on grandmother's specific phone without changing her
 * account-level default).
 *
 * Payload accepts any subset of:
 *   { skill_level_override, voice_alerts_enabled, font_scale,
 *     clear_overrides }
 *
 * @param {string|null} token
 * @param {string} deviceHash
 * @param {object} payload
 * @returns {Promise<object|null>}
 */
export async function patchDeviceOverrides(token, deviceHash, payload) {
  if (!token || !deviceHash) return null;
  try {
    const url = `${API_BASE}/api/v1/user/device/${encodeURIComponent(deviceHash)}/overrides`;
    const resp = await fetch(url, {
      method: "PATCH",
      headers: await _authHeaders(token, { "Content-Type": "application/json" }),
      body: JSON.stringify(payload || {}),
    });
    if (await _handleAuthedResponse(resp)) return null;
    if (!resp.ok) return null;
    return await resp.json();
  } catch {
    return null;
  }
}

/**
 * Fetch the freemium-threshold + paid-tier gating state for the user.
 *
 * Returns null when no auth token (anonymous user — server-side counter
 * isn't tracked) or when the API is unreachable. Callers should treat
 * null as "show no nudge" and gracefully degrade.
 *
 * Shape: { threats_blocked_lifetime, threshold, gated, tier,
 *          nudge_shown_at, nudge_count }
 *
 * @param {string|null} token JWT
 * @returns {Promise<object|null>}
 */
export async function fetchThreatStatus(token) {
  if (!token) return null;
  try {
    const resp = await fetch(`${API_BASE}/api/v1/user/threats/status`, {
      method: "GET",
      headers: await _authHeaders(token),
    });
    if (await _handleAuthedResponse(resp)) return null;
    if (!resp.ok) return null;
    return await resp.json();
  } catch {
    return null;
  }
}

/**
 * Increment the lifetime threat counter when extension blocks a scam.
 *
 * Best-effort: no error surfacing — the block already happened
 * client-side and the user shouldn't see a red toast because the
 * server counter sync flaked.
 *
 * @param {string|null} token JWT
 * @param {number} count number of threats freshly blocked since last sync
 * @returns {Promise<object|null>} updated status or null
 */
export async function incrementThreatCounter(token, count = 1) {
  if (!token || count < 1) return null;
  try {
    const resp = await fetch(`${API_BASE}/api/v1/user/threats/increment`, {
      method: "POST",
      headers: await _authHeaders(token, { "Content-Type": "application/json" }),
      body: JSON.stringify({ count }),
    });
    if (await _handleAuthedResponse(resp)) return null;
    if (!resp.ok) return null;
    return await resp.json();
  } catch {
    return null;
  }
}

/**
 * Link this browser to the signed-in account as a device
 * (POST /api/v1/me/devices, platform "extension"; utils/device-link.js).
 * Called by the background after sign-in and as a heartbeat; what a refusal
 * means for the session is decided in utils/auth-session.js.
 *
 * Sends the per-install id, the browser family ("Chrome") and the extension
 * version — no hostname, no history.
 *
 * @param {string|null} token JWT
 * @param {{platform: string, appVersion: string}} info  platform = browser family
 * @returns {Promise<{ok: true} | {ok: false, error: string}>}
 */
export async function registerDevice(token, { platform, appVersion } = {}) {
  return linkDevice({
    fetchImpl: (url, init) => fetch(url, init),
    apiBase: API_BASE,
    token,
    deviceId: await getDeviceHash(),
    browser: platform,
    appVersion,
  });
}

/**
 * Extract unique domains from a list of URLs
 * @param {string[]} urls
 * @returns {string[]}
 */
export function extractDomains(urls) {
  const domains = new Set();
  for (const url of urls) {
    try {
      const parsed = new URL(url.startsWith("http") ? url : `https://${url}`);
      if (parsed.hostname && parsed.hostname !== "localhost") {
        domains.add(parsed.hostname.toLowerCase());
      }
    } catch {
      // Skip invalid URLs
    }
  }
  return [...domains];
}

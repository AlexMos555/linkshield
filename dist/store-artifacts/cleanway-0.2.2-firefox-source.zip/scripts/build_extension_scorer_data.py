#!/usr/bin/env python3
"""Build the browser extension's copy of the server's name-rule data.

The extension scores a site with no network before (and, when the API is
slow or unreachable, instead of) asking the server. Its brand list was a
hand-copied 50 names with no Russian brand, and its PSL helper knew no
Russian zone: sberbamk.ru and t1nkoff.ru scored 0, kvs.gov.spb.ru (the St
Petersburg government) 50/caution. The server fixed both in PRs #61 and #62;
this script carries the fix across instead of a second hand copy.

Everything is read from the server's own module, api.services.scoring, which
loads it from data/typosquat_targets.json, data/typosquat_targets_ru.json and
data/ru_public_suffixes.json — so the extension compares against exactly the
names, official domains, exemptions and per-name switches the server does.
Evidence strings stay on the server; the extension only needs the verdicts.

Outputs:
    packages/extension-core/src/utils/scorer-data.js
        The data, as a classic script that sets `cleanwayScorerData` on the
        global object (content scripts) or `self` (the background module).
        Read by src/utils/name-rules.js.
    tests/data/extension_name_rules_parity.tsv
        What the server's name rules answer for ~6,000 hosts: the labelled
        Russian sets, every listed brand domain, the seeded typo variants of
        every Russian brand name and a sample of the global ones, and edge
        cases. scripts/test-local-scorer.mjs holds the JavaScript port of the
        rules (name-rules.js) to this table in all four extension trees, so
        a server rule change that is not ported fails CI.

Usage:
    python3 scripts/build_extension_scorer_data.py           # write both
    python3 scripts/build_extension_scorer_data.py --check   # exit 1 if stale
    bash scripts/build-extensions.sh                          # then fan out

No network. tests/test_extension_scorer_data.py runs --check in pytest.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Iterable, Optional

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

DATA_JS = ROOT / "packages" / "extension-core" / "src" / "utils" / "scorer-data.js"
PARITY_TSV = ROOT / "tests" / "data" / "extension_name_rules_parity.tsv"
LABELLED_SETS = (
    ROOT / "tests" / "data" / "ru_heuristics_legit.txt",
    ROOT / "tests" / "data" / "ru_heuristics_phish.txt",
    ROOT / "data" / "benchmark_legit_ru.txt",
)
# One in this many seeded variants of the GLOBAL brands goes into the parity
# table (all of the Russian ones do): the global rules did not change in this
# port's source PRs, and 8,000 rows would add little but size.
GLOBAL_VARIANT_STRIDE = 4

# Shapes the rules were changed for, each named in PR #61 / #62 or found
# while porting. Not labelled: the table records whatever the server says.
EDGE_CASES = (
    # #61: PSL-aware registrable domain, length rules, fake TLDs under zones
    "kvs.gov.spb.ru", "zenit.kfis.gov.spb.ru", "gov.spb.ru", "ako.ru", "etsp.ru", "ngpedia.ru",
    "ikar.ru", "ugpr.ru", "spb.ru", "adm.nov.ru", "museum.vladimir.ru", "vk.com.msk.ru",
    "gosuslugi.gov.msk.ru", "paypal.com.spb.ru", "sberbank.ru.msk.ru", "com.msk.ru",
    "edu.gov.ru", "a.edu.gov.ru", "x.spb.ru", "a.b.hosting.myjino.ru", "b.hosting.myjino.ru",
    "dhl.top", "dh1.com", "up5.com", "1kea.com", "eb4y.com", "c1ti.com", "dhll.com", "upss.com",
    "office365.com", "0ffice365.com", "sberbank.spb.ru", "vk.nov.ru", "gosuslugi-lk.spb.ru",
    "vk-login.nov.ru", "ok-stroy.spb.ru", "gook.spb.ru", "paypal.spb.ru", "paypal.com.ru",
    "cdek.msk.ru", "beeline.com.ru", "megafon.spb.ru",
    # #62: Russian brands, exemptions, slips, shared names, zones
    "sberbamk.ru", "t1nkoff.ru", "gosuslugl.ru", "0zon.ru", "wildberies.ru", "avlto.ru",
    "yandex.ru.com", "yandx.ru", "yandx.ru.com", "vk.ru.com", "mail.ru.com", "avito-ru.com",
    "sberbank-ru.com", "sberbankru.com", "gosuslugirus.ru", "vtb-team.ru", "theozon.ru",
    "tbankapp.ru", "mtscom.ru", "vkweb.ru", "thevk.net", "gomts.com", "mts-team.com",
    "trybeeline.com", "ozonweb.com", "ozon.shop", "vtb.top", "ozon.pl", "ozon.co", "tbank.com",
    "tbank.help", "tele2.top", "tele5.de", "megafox.ru", "tirkoff.ru", "beelink.ru",
    "swedbank.com", "mbank.pl", "upstore.ru", "aviator.com", "kontakt.ru", "rutor.ru",
    "altabank.ru", "oberbank.at", "gazorombank.ru", "sovkombank.ru", "yandez.ru", "magafon.ru",
    "wegafon.ru", "51gosuslugi.ru", "23gosuslugi.ru", "irsnet.gov", "mydpd.at", "myups.biz",
    "dhllogin.com", "ozone.pl", "zoon.ru", "megafoon.nl",
    "xn--90ab2c.xn--p1ai", "www.xn--90ab2c.xn--p1ai", "online.xn--90ab2c.xn--p1ai",
    "xn--90ab2c.xn--p1acf", "xn--80abap1arsf.xn--p1ai", "xn--c1aapkosapc.xn--p1ai", "xn--90ab2c.com",
    # the extension's own regression table (scripts/test-local-scorer.mjs)
    "google.com", "paypal.com", "github.io", "metamask.github.io", "paypa1.com",
    "paypal.evil.com", "paypal.com.evil.xyz", "wellsfargo-secure.com", "rnetamask.io",
    "apple.com.cn", "hsbc.co.uk", "barclays.co.uk", "signin.ebay.co.uk", "store.steampowered.com",
    "login.microsoftonline.com.evil.tk", "sub.domain.example.co.uk", "www.shop.co.uk",
    "xn--pypal-4ve.com", "xn--80ak6aa92e.com", "paypal.xn--80abap1arsf.xn--p1ai",
    "secure-login-paypal-verify.tk", "google.ru", "amazon.de", "yandex.kz",
    # #80: a brand with a lure word as a site on a hosting platform
    "sberbank-online.pages.dev", "gosuslugi-vhod.netlify.app", "ozon-priz.vercel.app",
    "lk-gosuslugi.web.app", "sberbank.tw1.ru", "gosuslugi.netlify.app", "vtb-login.pages.dev",
    "paypal-login.netlify.app", "zoom-sign-in.vercel.app", "adobesignin.netlify.app",
    "apple-id-verify.web.app", "netflix-clone.vercel.app", "sber-hackathon.github.io",
    "vkusvill-bonus.netlify.app", "mtsdelivery.vercel.app", "vk.github.io", "sber.bank.in",
    "app.netlify.com", "www.netlify.app", "netlify.app", "a.b.sberbank-bonus.vercel.app",
    "xn--c1aapkosapc-lk.netlify.app", "sberbank-bonus.tw1.ru",
    # 2026-10-05: global brands with a measured false-positive pass (slip
    # rule, official/unrelated lists, trezor as a shared name)
    "allegro.pl-dyu8h.sbs", "allegrolokalnie.oferta-0295748.cfd", "olx.pl-dyu8h.sbs", "mbway.online",
    "att-sign-in-1c41ac.webflow.io", "my-xfinitysignin.weebly.com", "novobanco.novoalerta.com",
    "nfinity.com", "myway.com", "comcash.com", "dfinity.org", "trezor.cz", "trezor.top", "olx.ua",
    "att.net", "bellmouth.com", "xfimity.com", "allegrro.pl",
    # 2026-10-15: tenant lure words with a counter, glued, or support/security
    "facebooklogin17.blogspot.com", "facebook-login0.blogspot.com", "facebookloginuser.blogspot.com",
    "facebook-supports.blogspot.com", "gmail-support.netlify.app", "facebook-new-security.blogspot.com",
    "facebook-benjamin.blogspot.com", "netflix-lake.vercel.app", "facebook-2024.blogspot.com",
    "mb-way.ns01.info", "gedivan.duckdns.org",
    # 2026-10-23: look-alike characters inside a brand combo, several
    # hyphenated words with a lure keyword (global brands), and what must
    # stay unflagged next to them
    "g00glemail.com", "go0glemail.com", "faceb00kmail.com", "ad0belogin.com", "micr0soft-login.com",
    "micr0softlogin.com", "paypa1-login.com", "secure-paypa1.com", "outlook-de-login.com",
    "paypal-secure-login.com", "secure-paypal-login.com", "apple-id-verify.com", "netflix-billing-update.com",
    "amazon-de-sign-in.com", "micr0soft-account-verify.com", "googlemail-login.com", "paypallogin-secure.com",
    "5berbank-bonus.ru", "0zon-priz.ru", "0zon-priz.spb.ru", "ozonapp-priz.spb.ru", "santander-pl.com",
    "amazon-de-support.com", "paypalito-login-guide.com", "72-bonus.ru", "up5-help.com",
    "office365-tips-and-tricks.com", "rnicrosoft-de-login.com",
    # 2026-10-23: tenant zones kept whatever their rank (data/tenant_zones.json)
    "paypal-login.trycloudflare.com", "debate-modifications-smilies-introduces.trycloudflare.com",
    "microsoft-verify.cloud.goog", "sberbank-bonus.jcloud.kz", "apple-id-verify.s3.cloud.ru",
    "zq7x1random.s3.cloud.ru", "gosuslugi.s3-website.cloud.ru", "lk-vtb.s3-alt.cloud.ru", "s3.cloud.ru",
    "www.s3.cloud.ru", "cloud.ru", "netflix-billing-update.ngrok-free.app", "paypal-verify.us.kg",
    # 2026-10-23, review of PR #309: 'secure booking' engines and the booking
    # phishing next to them; a look-alike brand in a hosting tenant's name
    "secure-direct-hotel-booking.com", "securebooking-belfastairport.com", "secure-booking-engine.com",
    "hotel-booking-secure.net", "secure-online-booking.com", "secure-booking.com", "securebooking.com",
    "booking-secure.com", "booking-secure-login.com", "secure-booking-verify.com", "booking-confirm-reservation.com",
    "booking-account-update.com", "secure-booking.pages.dev",
    "paypa1-login.ngrok-free.app", "paypa1-login.us.kg", "5berbank-bonus.pages.dev",
    "micr0soft-login.trycloudflare.com", "faceb00k-login.netlify.app", "app1e-id-verify.vercel.app",
    "micr0softlogin.pages.dev", "paypa1.pages.dev", "72-bonus.pages.dev", "office365-tips.netlify.app",
    "netf1ix-clone.vercel.app", "micros0ft-account-verify.com",
    # 2026-10-28: the registrable domain by the Public Suffix List's ICANN
    # rules. Suffixes the compound-ccTLD heuristic did not know, the ones it
    # invented, wildcard and exception rules, and the private section that
    # stays out.
    "paypal-secure.my.id", "www.paypal-secure.my.id", "adsmanager-facebook.my.id", "apple-id.io.vn",
    "apiim-whatsapp.hl.cn", "paypa1.me.uk", "www.paypa1.me.uk", "shop.example.ltd.uk", "x.plc.uk",
    "www.england.nhs.uk", "a.city.lg.jp", "netbanking.hdfc.bank.in", "hsbc.bank.in", "sber.bank.in",
    "bet365.bet.br", "detran.sp.gov.br", "srv.hrdc-drhc.gc.ca", "www.web.de", "login.web.de", "web.de",
    "account.id.me", "api.id.me", "id.me", "www.school.sch.gr", "kau.gov.hu", "www.net.hr", "amazon.com.be",
    "x.com.de", "x.co.vu", "www.city.kobe.jp", "city.kobe.jp", "a.b.kobe.jp", "b.kobe.jp", "kobe.jp",
    "www.ck", "a.www.ck", "a.b.ck", "foo.github.io", "x.blogspot.com", "accounts.google.sn.cn",
    "allegro.gsm.pl", "my.id", "nhs.uk", "192.168.1.10", "[::1]", "localhost",
    # 2026-10-31: one colon is a port, not IPv6; a scheme is neither.
    "1.2.3.4:443", "2001:db8::1", "[2001:db8::1]", "https://alt-aj-https.mail.ru", "example.com:8080",
    # 2026-10-28, final review: the ccTLD default splits the free zones no
    # list knew (ChangeIP's ne.pw, asn.im, or.lt; FreeDNS's govt.hu, mil.nf)
    # and keeps the named ones (data/cctld_second_levels.json) one site.
    "paypal-login.ne.pw", "www.aceoouu-asosmaoemsnouu.adqxeha.ne.pw", "secure-paypal.asn.im",
    "microsoft-login.or.lt", "appleid-verify.sch.in", "office365-login.govt.hu", "usmc.mil.nf",
    "evil.com.tv", "login.evil.org.zz", "x.co.com", "www.in.gr", "www.ne.se", "repo.or.cz", "www.ne.ch",
    # malformed / degenerate input must not crash either side
    "a", "xn--", "xn---.com", "xn--a.com", "....xn--p1ai", "ru.com", "a.ru.com",
    # astral-plane letters: one character to Python, two UTF-16 units to JS
    # (p𝐚ypal with a mathematical bold a, pa😀ypal, сбер𝐚)
    "xn--pypal-cl00d.com", "xn--paypal-4v74e.com", "xn--90ai7ab24840d.com",
)


def _labelled_hosts() -> list[str]:
    hosts: list[str] = []
    for path in LABELLED_SETS:
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                hosts.append(line.split(" | ")[0].strip())
    return hosts


def _ascii_host(host: str) -> str:
    """The wire form the extension receives: each non-ASCII label punycoded."""
    from api.services.scoring import _ascii_label

    return ".".join(_ascii_label(label) for label in host.split("."))


def _variant_hosts() -> list[str]:
    sys.path.insert(0, str(ROOT / "scripts"))
    import eval_typo_variants as variants  # noqa: E402 — a sibling script, not a package

    ru = [r["host"] for r in variants.build_variants("ru")]
    world = [r["host"] for r in variants.build_variants("global")]
    return ru + world[::GLOBAL_VARIANT_STRIDE]


def parity_hosts() -> list[str]:
    """Every host the parity table covers, ASCII, in a stable order."""
    from api.services import scoring

    listed = sorted(d for d in scoring._BRAND_LEGIT_DOMAINS if d.isascii())
    candidates: Iterable[str] = (
        *EDGE_CASES,
        *_labelled_hosts(),
        *listed,
        *(f"www.{d}" for d in listed),
        *_variant_hosts(),
    )
    seen: set[str] = set()
    out: list[str] = []
    for host in candidates:
        ascii_host = _ascii_host(host.lower())
        if ascii_host not in seen:
            seen.add(ascii_host)
            out.append(ascii_host)
    return out


def server_verdict(host: str) -> list[str]:
    """The server's name rules on one ASCII host, as the table's columns."""
    from api.services import scoring

    unicode_host = scoring._decode_idn(host)
    typo = scoring._check_typosquatting_v2(unicode_host)
    return [
        host,
        f"{typo[0]}|{typo[1]}" if typo else "-",
        scoring._check_brand_in_subdomain(host) or "-",
        scoring._check_brand_under_open_zone(host) or "-",
        "1" if scoring._has_fake_tld_in_subdomain(host) else "0",
        str(scoring._apparent_subdomain_levels(host)),
        scoring.registrable_domain(host),
        scoring._check_brand_on_hosting_tenant(host) or "-",
    ]


PARITY_HEADER = (
    "# GENERATED by scripts/build_extension_scorer_data.py from api/services/scoring.py — do not edit.\n"
    "# The server's name rules on each host; scripts/test-local-scorer.mjs holds the extension's\n"
    "# port (packages/extension-core/src/utils/name-rules.js) to every row.\n"
    "# host\ttyposquat (legit|method)\tbrand_in_subdomain\tbrand_under_open_zone\tfake_tld\t"
    "subdomain_levels\tregistrable_domain\tbrand_on_hosting_tenant\n"
)


def render_parity() -> str:
    rows = ["\t".join(server_verdict(h)) for h in parity_hosts()]
    return PARITY_HEADER + "\n".join(rows) + "\n"


def _sorted(items: Iterable[str]) -> list[str]:
    return sorted(items)


def _flags(rule) -> str:
    """A _NameRule as five 0/1 flags, in field order."""
    return "".join("1" if getattr(rule, f) else "0" for f in rule._fields)


def _vendored_psl():
    """The vendored list the server loaded (api/services/public_suffix.py);
    refuse to build without it rather than ship the extension a heuristic."""
    from api.services import public_suffix

    if public_suffix.LIST is None:
        raise SystemExit(f"data/{public_suffix.PSL_FILE} did not load: {public_suffix.LOAD_ERROR}")
    return public_suffix.LIST


def _trie_entries(rules) -> list[list[str]]:
    """Every rule the registrable domain needs, as labels from the TLD down:
    the exact rules of two labels or more (a one-label rule is the default
    rule's answer anyway), each wildcard's base plus '*', and each exception
    with '!' on its leftmost label."""
    entries = [r.split(".")[::-1] for r in rules.exact if "." in r]
    entries += [w.split(".")[::-1] + ["*"] for w in rules.wildcards]
    for e in rules.exceptions:
        labels = e.split(".")[::-1]
        entries.append(labels[:-1] + ["!" + labels[-1]])
    return entries


def icann_suffix_trie(rules) -> dict[str, str]:
    """The rules as {TLD: its rules below it}, each a trie of labels from
    the TLD down: siblings sorted and joined by ',', a node's children in
    '(…)', '+' in front of a label that is a rule itself AND has children (a
    leaf always is one). {"jp": "…,kobe(!city,*),…", "uk": "+co,…,sch(*)"}
    is *.kobe.jp, !city.kobe.jp, co.uk and *.sch.uk.

    Keyed by TLD so the extension decodes only the TLD a host is under, on
    first use: no ICANN rule has two labels under .com, .net or .org, so most
    pages decode nothing, and .jp, the largest (1,776 rules), takes about a
    millisecond. 39.3 KB for the 2026-10-22 list (16.8 KB gzipped), against
    68 KB as a comma-joined list and 79 KB as a JSON array: content scripts
    load it on every page."""
    trie: dict = {}
    for labels in _trie_entries(rules):
        node = trie
        for label in labels:
            node = node.setdefault(label, {})
        node[""] = {}

    def encode(node: dict) -> str:
        out = []
        for label in sorted(k for k in node if k):
            child = node[label]
            kids = {k: v for k, v in child.items() if k}
            if kids:
                out.append(("+" if "" in child else "") + label + "(" + encode(kids) + ")")
            else:
                out.append(label)
        return ",".join(out)

    return {tld: encode(node) for tld, node in sorted(trie.items())}


def decode_icann_suffix_trie(tries: dict[str, str]) -> tuple[frozenset[str], frozenset[str], frozenset[str]]:
    """(exact rules, wildcard bases, exception names) back from
    icann_suffix_trie(): what name-rules.js's decoder builds, for the test."""
    exact: set[str] = set()
    wild: set[str] = set()
    exc: set[str] = set()

    def parse(text: str, pos: int, suffix: str) -> int:
        while True:
            terminal = text.startswith("+", pos)
            pos += terminal
            end = pos
            while end < len(text) and text[end] not in ",()":
                end += 1
            label, pos = text[pos:end], end
            name = f"{label}.{suffix}"
            kids = text.startswith("(", pos)
            if label == "*":
                wild.add(suffix)
            elif label.startswith("!"):
                exc.add(f"{label[1:]}.{suffix}")
            elif terminal or not kids:
                exact.add(name)
            if kids:
                pos = parse(text, pos + 1, name) + 1  # past ')'
            if text.startswith(",", pos):
                pos += 1
                continue
            return pos

    for tld, text in tries.items():
        if parse(text, 0, tld) != len(text):
            raise ValueError(f"icannSuffixes[{tld!r}] does not parse to its end")
    return frozenset(exact), frozenset(wild), frozenset(exc)


def icann_suffix_counts(rules) -> list[int]:
    """[exact rules of 2+ labels, wildcards, exceptions]."""
    return [sum("." in r for r in rules.exact), len(rules.wildcards), len(rules.exceptions)]


def scorer_data() -> dict:
    """The name-rule data the extension needs, from the server's module."""
    from api.services import hosting_platforms, public_suffix, ru_lures, scoring

    psl = _vendored_psl()
    targets = list(scoring.TYPOSQUAT_TARGETS.items())
    global_names = list(scoring.GLOBAL_TYPOSQUAT_TARGETS)
    # The merge puts the global list first, in its own order; the port relies
    # on it (brand_in_subdomain reads the first globalCount entries only).
    assert [n for n, _ in targets[: len(global_names)]] == global_names, "global brands must come first"
    rule_fields = list(scoring._NameRule._fields)
    return {
        "targets": [[n, d] for n, d in targets],
        "globalCount": len(global_names),
        "ruleFields": rule_fields,
        "rules": {n: [_flags(scoring._NAME_RULES[n]), _flags(scoring._NAME_RULES_AT_HOME[n])] for n, _ in targets},
        "officialDomains": _sorted(scoring._BRAND_OFFICIAL_DOMAINS),
        "unrelatedDomains": _sorted(scoring._BRAND_LEGIT_DOMAINS - scoring._BRAND_OFFICIAL_DOMAINS),
        "notTypos": {n: _sorted(v) for n, v in sorted(scoring._BRAND_NOT_TYPOS.items())},
        "sharedNames": _sorted(scoring._SHARED_NAMES),
        "ruPublicSuffixes": _sorted(scoring.RU_PUBLIC_SUFFIXES),
        "ruWildcardSuffixes": _sorted(scoring._RU_WILDCARD_SUFFIXES),
        "ruRestrictedZones": _sorted(scoring._RU_RESTRICTED_ZONES),
        "restrictedZoneLabels": _sorted(scoring._RESTRICTED_ZONE_LABELS),
        "regionalGovernmentDomains": _sorted(scoring.REGIONAL_GOVERNMENT_DOMAINS),
        "cctldSecondLevels": _sorted(public_suffix.CCTLD_SECOND_LEVELS),
        # registrable_domain(): the PSL's ICANN rules (icann_suffix_trie) —
        # the Russian zones are ruPublicSuffixes, applied first, as on the
        # server — with the list's version and the rule counts the port's
        # decoder is checked against (scripts/test-local-scorer.mjs).
        "icannSuffixes": icann_suffix_trie(psl.icann),
        "icannSuffixesVersion": psl.version,
        "icannSuffixCounts": icann_suffix_counts(psl.icann),
        # The ccTLD default (public_suffix.SuffixRules.cc_second_levels): each
        # of cctldSecondLevels under a 2-letter TLD is a suffix but for these
        # zones, one owner's names (data/cctld_second_levels.json), as on the
        # server.
        "cctldNames": _sorted(public_suffix.CCTLD_NAMES),
        "fakeTldLabels": _sorted(scoring._FAKE_TLD_LABELS),
        "registeredFakeTldLabels": _sorted(scoring._REGISTERED_FAKE_TLD_LABELS),
        "ruZoneBrands": list(scoring._RU_ZONE_BRANDS_LONGEST_FIRST),
        "ruZoneBrandPartMin": scoring._RU_ZONE_BRAND_PART_MIN,
        "lureTlds": _sorted(scoring._LURE_TLDS),
        "ruTlds": _sorted(scoring._RU_TLDS),
        "ruLookalikeZones": _sorted(scoring._RU_LOOKALIKE_ZONES),
        "charSubs": dict(sorted(scoring._CHAR_SUBS.items())),
        "confusables": dict(sorted(scoring._CONFUSABLES.items())),
        "glyphSubs": [list(pair) for pair in scoring._GLYPH_SUBS],
        "keyboardRows": [list(rows) for rows in scoring._KEYBOARD_ROWS],
        "similarLetters": _sorted("".join(sorted(pair)) for pair in scoring._SIMILAR_LETTERS),
        "vowels": "".join(sorted(scoring._VOWELS)),
        "genericTails": list(scoring._GENERIC_TAILS),
        "comboKeywords": _sorted(scoring._COMBOSQUAT_KEYWORDS),
        "comboGenericSuffixes": _sorted(scoring._COMBO_GENERIC_SUFFIXES),
        "comboGenericPrefixes": _sorted(scoring._COMBO_GENERIC_PREFIXES),
        "comboCountrySuffixes": _sorted(scoring._COMBO_COUNTRY_SUFFIXES),
        # Russian lure words (ru_lures) as skeletons, and the tables the
        # skeleton is built from, so the port folds spellings exactly as the
        # server does instead of keeping its own copy of them.
        # _check_brand_on_hosting_tenant: every suffix tenant_suffix_of() is
        # given by the scorer, the platforms' own hosts, the zones it skips
        # and the brands it looks for, in the server's order.
        "hostingTenantSuffixes": _sorted(scoring._SCORER_SHARED_SUFFIXES | hosting_platforms.TENANT_SUFFIXES),
        "operatorHosts": _sorted(hosting_platforms.OPERATOR_HOSTS),
        "registryOnlyZones": _sorted(scoring._REGISTRY_ONLY_ZONES),
        "hostingTenantBrands": list(scoring._HOSTING_TENANT_BRANDS),
        # _is_tenant_lure: the extra lure words and the glued-prefix lures.
        "tenantExtraLures": _sorted(scoring._TENANT_EXTRA_LURES),
        "tenantGluedLures": list(scoring._TENANT_GLUED_LURES),
        "lureWords": _sorted(ru_lures.LURE_WORDS),
        "lureStems": list(ru_lures.LURE_STEMS),
        "brandLureWords": {n: _sorted(v) for n, v in sorted(scoring._BRAND_LURE_WORDS.items())},
        "skeletonCyrillic": dict(ru_lures._CYRILLIC_TO_LATIN),
        "skeletonFolds": [list(pair) for pair in ru_lures._LATIN_FOLDS],
        "skeletonDigits": {chr(k): v for k, v in sorted(ru_lures._DIGIT_LETTERS.items())},
        "typosquatMinLabel": scoring._TYPOSQUAT_MIN_LABEL,
        "shapeMinLabel": scoring._SHAPE_MIN_LABEL,
        "fuzzyMinLabel": scoring._FUZZY_MIN_LABEL,
        "twoEditMinLabel": scoring._TWO_EDIT_MIN_LABEL,
        "lookalikeComboMinLabel": scoring._LOOKALIKE_COMBO_MIN,
        "notLureNextTo": {brand: sorted(words) for brand, words in sorted(scoring._NOT_LURE_NEXT_TO.items())},
    }


DATA_JS_HEADER = """\
// GENERATED by scripts/build_extension_scorer_data.py — do not edit by hand.
//
// The server's name-rule data (api/services/scoring.py, loaded there from
// data/typosquat_targets.json, data/typosquat_targets_ru.json,
// data/ru_public_suffixes.json and data/public_suffix_list.dat): the brands
// the typosquat rule compares against, every Russian brand family's official
// domains and the verified same-shaped sites of other owners, the per-name
// switches, the Russian public suffixes, the Public Suffix List's ICANN
// rules and the rule constants. Read by name-rules.js.
//
// To change it, edit the data file or the server rule, then run
//     python3 scripts/build_extension_scorer_data.py
//     bash scripts/build-extensions.sh
// CI (tests/test_extension_scorer_data.py) fails when this file is stale.
//
// A classic script, like link-target.js: a content script gets the global,
// the background module imports it for its side effect, Node tests load it
// in a vm context. Data only — no DOM, no chrome.*.
"""


def attribution_comment() -> str:
    """hostingTenantSuffixes are the public-suffix rules under the ranked
    names (data/public_suffixes_in_top.json), adapted from the Majestic
    Million (CC BY 3.0) and the Chrome UX Report (CC BY 4.0): their notice.
    icannSuffixes are the Public Suffix List's (MPL 2.0): its notice, and
    where its source form is — a URL, since MPL 2.0 §3.2(a) asks that the
    recipient of the shipped form can find it from the package alone (the
    2026-10-28 final review). cctldNames are Cleanway's own."""
    sys.path.insert(0, str(ROOT / "scripts"))
    from ranking_attribution import attribution_lines

    from api.services import public_suffix

    psl = _vendored_psl()
    return (
        "//\n// hostingTenantSuffixes:\n" + "".join(f"// {line}\n" for line in attribution_lines())
        + "//\n// icannSuffixes: the ICANN section of the Public Suffix List\n"
        + f"// ({public_suffix.PSL_URL}), VERSION {psl.version}, COMMIT {psl.commit},\n"
        + "// Mozilla Public License 2.0 (https://mozilla.org/MPL/2.0/). Source form:\n"
        + f"// {SOURCE_FORM_URL}\n"
        + "// (the unmodified list, as vendored; upstream at the COMMIT above). Changes\n"
        + "// made: the rules of two labels or more, wildcards and exceptions, in\n"
        + "// punycode, as a label trie (scripts/build_extension_scorer_data.py,\n"
        + "// icann_suffix_trie).\n"
    )


# Where the shipped PSL's source form is (attribution_comment): the public
# repository's vendored copy.
SOURCE_FORM_URL = "https://github.com/AlexMos555/linkshield/blob/main/data/public_suffix_list.dat"


def render_data_js() -> str:
    # One key per line, each value compact: a data change shows as a changed
    # line under its key, and the file stays small enough to load per page.
    lines = [
        f"    {json.dumps(key)}: {json.dumps(value, ensure_ascii=False, separators=(',', ':'))}"
        for key, value in scorer_data().items()
    ]
    return (
        DATA_JS_HEADER
        + attribution_comment()
        + "(function (root) {\n"
        + '  "use strict";\n'
        + "  root.cleanwayScorerData = {\n"
        + ",\n".join(lines)
        + "\n  };\n"
        + '})(typeof self !== "undefined" ? self : globalThis);\n'
    )


OUTPUTS = ((DATA_JS, render_data_js), (PARITY_TSV, render_parity))


def main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--check", action="store_true", help="exit 1 when an output is stale, write nothing")
    args = ap.parse_args(argv)
    stale = []
    for path, render in OUTPUTS:
        text = render()
        current = path.read_text(encoding="utf-8") if path.exists() else None
        if current == text:
            continue
        if args.check:
            stale.append(path.relative_to(ROOT))
        else:
            path.write_text(text, encoding="utf-8")
            print(f"wrote {path.relative_to(ROOT)}")
    if stale:
        print(
            "Stale: " + ", ".join(str(p) for p in stale)
            + ". Run: python3 scripts/build_extension_scorer_data.py && bash scripts/build-extensions.sh",
            file=sys.stderr,
        )
        return 1
    if args.check:
        print("extension scorer data: OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
